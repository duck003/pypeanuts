from pycat.core import Window, Sprite
w = Window()
s = w.create_sprite(scale=200, position=w.center)
w.run()
